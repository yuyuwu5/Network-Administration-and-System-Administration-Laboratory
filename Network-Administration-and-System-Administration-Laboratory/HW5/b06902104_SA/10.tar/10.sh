#!/bin/env bash
mkdir /repo
pacman-key --add $(pwd)/public.key
echo "[nasa-repo]
SigLevel = Optional TrustAll
Server =  file:///repo" >> /etc/pacman.conf
cp $(pwd)/sudo-oasis-0.1-1-any.pkg.tar.xz /repo
cp $(pwd)/sudo-oasis-0.1-1-any.pkg.tar.xz.sig /repo
repo-add /repo/nasa-repo.db.tar.gz sudo-oasis-0.1-1-any.pkg.tar.xz
